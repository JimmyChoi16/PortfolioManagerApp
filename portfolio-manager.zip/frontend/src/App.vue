<template>
  <router-view />
</template>

<script setup>
// Main App component - routing is handled by router-view
</script>

<style>
/* Global app styles are in style.css */
</style>